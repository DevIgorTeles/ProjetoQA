Implementação prevista nas etapas seguintes. Nenhum resultado de teste é declarado na Fase 1.
