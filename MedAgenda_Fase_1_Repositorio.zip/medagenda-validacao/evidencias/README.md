Evidências de execução serão registradas nas próximas etapas, sem dados reais ou tokens.
